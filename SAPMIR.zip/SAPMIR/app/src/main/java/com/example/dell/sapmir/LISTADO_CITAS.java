package com.example.dell.sapmir;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import android.widget.SimpleAdapter;

public class LISTADO_CITAS extends AppCompatActivity {

    private EditText etNombre,etObservacion,etTelefono,etFecha,etHora;
    private ListView lwCitas;

    private ListView lv;
    private ArrayList<ImageModel> imageModelArrayList;
    private int[] myImageList = new int[]{R.drawable.arrow };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado__citas);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
             @Override
            public void onClick(View view) {
                 startActivity(new Intent(LISTADO_CITAS.this,Citas.class));
              //  Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //        .setAction("Action", null).show();
            }
        });
        lwCitas=(ListView)findViewById(R.id.lwCitas);

  //String[] nombres=Buscar();
     //   imageModelArrayList = populateList();
        // imageModelArrayList = populateList();
        List<HashMap<String, String>> aList = new ArrayList<HashMap<String, String>>();

        aList=populateList();
        String[] from = {"listview_image", "listview_title", "listview_discription"};
        int[] to = {R.id.listview_image, R.id.listview_item_title, R.id.listview_item_short_description};



        SimpleAdapter simpleAdapter = new SimpleAdapter(getBaseContext(), aList, R.layout.list_item_tabla, from, to);
        ListView androidListView = (ListView) findViewById(R.id.lwCitas);
        androidListView.setAdapter(simpleAdapter);

        //  ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,R.layout.list_item_tabla,R.id.Itemname,nombres);

        //lwCitas.setAdapter(adapter);
         lwCitas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
               Toast.makeText(LISTADO_CITAS.this,lwCitas.getItemAtPosition(i).toString(),Toast.LENGTH_SHORT).show();
           /*      Calendar calendarNow = new GregorianCalendar(TimeZone.getTimeZone("Europe/Madrid"));
                 int monthDay =calendarNow.get(Calendar.DAY_OF_MONTH);
                 int month = calendarNow.get(Calendar.MONTH);
                 int year = calendarNow.get(Calendar.YEAR);

                 Toast.makeText(LISTADO_CITAS.this,"fecha "+ monthDay +" " +month+" " + year,Toast.LENGTH_LONG).show();
         */
             }
         });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_listado__cita, menu);
        Toast.makeText(this,"aqui 1",Toast.LENGTH_SHORT).show();
        // imageModelArrayList = populateList();
        List<HashMap<String, String>> aList = new ArrayList<HashMap<String, String>>();

        aList=populateList();
                String[] from = {"listview_image", "listview_title", "listview_discription",};
        int[] to = {R.id.listview_image, R.id.listview_item_title, R.id.listview_item_short_description};




        SimpleAdapter simpleAdapter = new SimpleAdapter(getBaseContext(), aList, R.layout.list_item_tabla, from, to);
        ListView androidListView = (ListView) findViewById(R.id.lwCitas);
        androidListView.setAdapter(simpleAdapter);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        Toast.makeText(this,"alla",Toast.LENGTH_SHORT).show();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public  List<HashMap<String, String>>  populateList(){
        List<HashMap<String, String>> aList = new ArrayList<HashMap<String, String>>();

        ArrayList<ImageModel> list = new ArrayList<>();


        BaseDatos db=new BaseDatos(this,"SAPMIR",null,3);

        String sql="select nombre,observacion,fecha,tiempo from cita ";
        Cursor filas=db.buscar(sql,db);
        String cDatos[]=new String[filas.getCount()];
        String[] listviewTitle = new String[filas.getCount()] ;
        int[] listviewImage = new int[]{
                R.mipmap.ic_launcher, R.mipmap.ic_launcher, R.mipmap.ic_launcher, R.mipmap.ic_launcher,
                R.mipmap.ic_launcher, R.mipmap.ic_launcher, R.mipmap.ic_launcher, R.mipmap.ic_launcher,
        };
         String[] listviewShortDescription = new String[filas.getCount()];
        int x=0;
        if (filas != null) {
            if (filas.moveToFirst()) {
                do {

                    HashMap<String, String> hm = new HashMap<String, String>();
                    hm.put("listview_title", filas.getString(0));
                    hm.put("listview_discription", filas.getString(1)
                            + "\n" + filas.getString(2)+ "\n" +filas.getString(3) );

                            hm.put("listview_image",  Integer.toString(listviewImage[x]));
                    aList.add(hm);

                    x=x+1;
                } while (filas.moveToNext());
            }
        }else{

            Toast.makeText(this,"No tiene registros en la base de datos",Toast.LENGTH_SHORT).show();
        }

        db.close();


        return aList;

    }


}
