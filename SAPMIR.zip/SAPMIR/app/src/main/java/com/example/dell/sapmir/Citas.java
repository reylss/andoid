package com.example.dell.sapmir;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


import android.app.DatePickerDialog;
import android.app.Dialog;
import android.widget.TextView;
import java.util.Calendar;
import android.widget.DatePicker;
public class Citas extends AppCompatActivity {
    private EditText etNombre,etTelefono,etHora;
    private Spinner etObservacion;
    private DatePicker datePicker;
    private Calendar calendar;
    private TextView etFecha;
    private int year, month, day;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_citas);
        etFecha = (TextView) findViewById(R.id.txtfecha);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month+1, day);

        etNombre=(EditText) findViewById(R.id.txtNombre);
        etObservacion=(Spinner)findViewById(R.id.txtObservacion);
        etTelefono=(EditText)findViewById(R.id.txtFelefono);
        etHora=(EditText)findViewById(R.id.txttiempo);
        String [] opciones= {"Terapia","Consulta","Resultado","Otros"};
        ArrayAdapter<String> adapter=new ArrayAdapter<String>( this,R.layout.spinner_item_tipo, opciones);
        etObservacion.setAdapter(adapter);
    }

    public void Retornar(View view){
        Intent i=new Intent(this,LISTADO_CITAS.class);
        startActivity(i);
    }


    public void Regidtar(View view){

        BaseDatos db=new BaseDatos(this,"SAPMIR",null,3);
        String nombre =etNombre.getText().toString();
        String observacion =etObservacion.getSelectedItem().toString();
         String telefono = etTelefono.getText().toString();
        String fecha =etFecha.getText().toString();
        String hora =etHora.getText().toString();

        if(!nombre.isEmpty() && !observacion.isEmpty() && !telefono.isEmpty() && !fecha.isEmpty() && !hora.isEmpty()){
            ContentValues registro=new ContentValues();
            registro.put("nombre",nombre);
            registro.put("observacion",observacion);
            registro.put("fecha",fecha);
            registro.put("tiempo",hora);
            db.insertar(registro,db);

            etNombre.setText("");
            etTelefono.setText("");
            etFecha.setText("");
            etHora.setText("");
            Toast.makeText(this,"Registro exitoso",Toast.LENGTH_LONG).show();
            Intent i=new Intent(this,LISTADO_CITAS.class);
            startActivity(i);
        }else{
            Toast.makeText(this,"Debe llenar todos los registros",Toast.LENGTH_SHORT).show();
        }
        db.close();
    }


    public void Modificar(View view){
        Intent i=new Intent(this,LISTADO_CITAS.class);
        startActivity(i);
    }
    public void Guardar(View view){
        Regidtar(  view);

    }
    public void Eliminar(View view){

        Intent i=new Intent(this,LISTADO_CITAS.class);
        startActivity(i);
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker arg0,
                                      int arg1, int arg2, int arg3) {
                    // TODO Auto-generated method stub
                    // arg1 = year
                    // arg2 = month
                    // arg3 = day
                    showDate(arg1, arg2+1, arg3);
                }
            };

    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
        Toast.makeText(getApplicationContext(), "ca",
                Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, year, month, day);
        }
        return null;
    }
    private void showDate(int year, int month, int day) {
        etFecha.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }
}
