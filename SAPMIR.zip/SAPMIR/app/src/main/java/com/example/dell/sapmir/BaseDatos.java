package com.example.dell.sapmir;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BaseDatos extends SQLiteOpenHelper {


    public BaseDatos(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table cita(id  INTEGER PRIMARY KEY AUTOINCREMENT, nombre text,observacion text,fecha TIMESTAMP NOT NULL DEFAULT current_timestamp,tiempo TEXT NOT NULL,telefono text);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void insertar(ContentValues registro ,BaseDatos db){
        SQLiteDatabase dbDatos=db.getWritableDatabase();
        dbDatos.insert("cita",null,registro);

    }
    public void modificar(ContentValues registro){


    }
    public void eliminar(ContentValues registro){


    }
    public Cursor buscar(String sql,BaseDatos db){
        SQLiteDatabase dbDatos=db.getWritableDatabase();
        Cursor filas=dbDatos.rawQuery(sql,null);

        return filas;

    }

}

